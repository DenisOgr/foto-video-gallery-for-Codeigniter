-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 27, 2012 at 02:53 AM
-- Server version: 5.1.40
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `foto2`
--

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `gid` int(10) NOT NULL AUTO_INCREMENT,
  `section_id` int(10) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL COMMENT 'video - для видео контента pic -  для графического контента',
  `name` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL COMMENT 'У картинок здесь будет путь к файлу, у видео контента - путь к картинке заглушки',
  `file_tmp` varchar(255) NOT NULL,
  `code` text NOT NULL,
  `mod` int(1) NOT NULL DEFAULT '0',
  `num` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `picture_id` (`gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gid`, `section_id`, `type`, `name`, `file`, `file_tmp`, `code`, `mod`, `num`) VALUES
(65, 90, 'video', 'Vimeo', '', 'Untitled3_1327617680209_thumb.png', 'http://vimeo.com/35572658', 1, 0),
(62, 89, 'img', 'Банан', 'banana_1327617461393.jpg', 'banana_1327617461393_thumb.jpg', '', 1, 0),
(63, 89, 'img', 'Клубника', 'strawberries-615_1327617462690.gif', 'strawberries-615_1327617462690_thumb.gif', '', 1, 0),
(64, 90, 'video', 'YouTube', '', 'Untitled-2_132761768063_thumb.png', 'http://www.youtube.com/watch?v=owGykVbfgUE&feature=player_detailpage', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE IF NOT EXISTS `sections` (
  `section_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  `file_tmp` varchar(100) NOT NULL,
  `mod` int(1) NOT NULL DEFAULT '0',
  `num` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `section_id` (`section_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=91 ;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`section_id`, `name`, `desc`, `type`, `file_tmp`, `mod`, `num`) VALUES
(89, 'Фрукты', '', 'img', 'apple_logo_rainbow_fruit_132761742449_thumb.jpg', 1, 0),
(90, 'Old Spice', '', 'video', 'Old-Spice_1327617546856_thumb.gif', 1, 0);
